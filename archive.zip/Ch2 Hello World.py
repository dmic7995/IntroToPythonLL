#
# Example file for HelloWorld
#

def main():
    print ("Hello world!") #General way to print constants or variables in python
    # name = input("What is your name? ") #General statement used to read Strings
    # print ("Nice to meet you,", name) #General way to print statements and strings together

if __name__ == "__main__":
    main() #When this file opens up, the python interpreter
           #is going to look if __name__ == __main__
           #Lines 10 & 11 help to distinguish whether a file is being included in another program 
           #or when that code is bring executed as its own program